## README

 - In line 35, choose a distribution (it can be 'uniform', 'normal', 'binomial', or 'poisson')
 - If you'd like to tweak the prameters, feel free to do so:
   + N = population size
   + n = sample size
   + m = mean, sd = standard deviation (Applicable for gaussian distrb)
   + p = probability p (for the binomial distrb)
   + lam = $\lambda$ (for the poisson distribution)
   